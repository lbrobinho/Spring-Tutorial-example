package com.bo.springdemo.Coach;

public interface Coach {

    public String getDailyWorkout();

    public String getDailyFortune();
}

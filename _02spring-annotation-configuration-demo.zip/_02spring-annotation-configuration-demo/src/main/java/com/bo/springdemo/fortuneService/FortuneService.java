package com.bo.springdemo.fortuneService;

public interface FortuneService {

    public String getFortune();
}
